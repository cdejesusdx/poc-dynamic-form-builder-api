﻿
namespace DynamicFormBuilder.Domain.Entities
{
    public class FormValidation
    {
        public bool Required { get; set; }
    }
}